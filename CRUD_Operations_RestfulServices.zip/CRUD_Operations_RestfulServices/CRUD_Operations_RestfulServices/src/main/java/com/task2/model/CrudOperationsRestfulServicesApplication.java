package com.task2.model;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CrudOperationsRestfulServicesApplication {

	public static void main(String[] args) {
		SpringApplication.run(CrudOperationsRestfulServicesApplication.class, args);
	}

}
