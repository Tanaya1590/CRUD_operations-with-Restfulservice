package com.task2.controller;


	import org.springframework.beans.factory.annotation.Autowired;
	import org.springframework.web.bind.annotation.*;
	import com.task2.model.Customer;
	import com.task2.repository.CustomerRepository;

	@RestController
	@RequestMapping("/api/customers")
	public class CustomerController {
	    @Autowired
	    private CustomerRepository customerRepository;
	    
	    @GetMapping("/")
	    public Iterable<Customer> getAllCustomers() {
	        return customerRepository.findAll();
	    }
	    
	    @GetMapping("/{id}")
	    public Customer getCustomerById(@PathVariable("id") Long id) {
	        return customerRepository.findById(id)
	                .orElseThrow(() -> new RuntimeException("Customer not found with id: " + id));
	    }
	    
	    @PostMapping("/")
	    public Customer createCustomer(@RequestBody Customer customer) {
	        return customerRepository.save(customer);
	    }
	    
	    @PutMapping("/{id}")
	    public Customer updateCustomer(@PathVariable("id") Long id, @RequestBody Customer updatedCustomer) {
	    	Customer customer = customerRepository.findById(id)
	                .orElseThrow(() -> new RuntimeException("Customer not found with id: " + id));
	        
	    	customer.setName(updatedCustomer.getName());
	        
	        return customerRepository.save(customer);
	    }
	    
	    @DeleteMapping("/{id}")
	    public void deleteCustomer(@PathVariable("id") Long id) {
	    	customerRepository.deleteById(id);
	    }
	}
